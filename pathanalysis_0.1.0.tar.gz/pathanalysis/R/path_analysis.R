#' Perform Path Analysis and Plot Results
#'
#' This function reads two CSV files, performs path analysis, and plots the results.
#' @param book1_path A string representing the path to the first CSV file.
#' @param book2_path A string representing the path to the second CSV file.
#' @return Creates path analysis output files and visualizes the results in a plot.
#' @examples
#' \dontrun{
#' path_analysis("path/to/book1.csv", "path/to/book2.csv")
#' }
#' @export
path_analysis <- function(book1_path, book2_path) {
   x <- read.csv(file = book1_path, header = TRUE)
  y <- read.csv(file = book2_path, header = TRUE)
  data <- cbind(y, x)

  cor.y <- correlation(y, x)$correlation
  cor.x <- correlation(x)$correlation
  Path <- path.analysis(cor.x, cor.y)

  write.csv(Path[["Residual"]], file = "My New File1.csv")
  write.csv(Path[["Coeff"]], file = "My New File.csv")

  par(mar = c(9, 0.0001, 0.0001, 0.001), pty = c("m"), usr = c(10, 2, 3, 4), xpd = TRUE)
  openplotmat()

  elpos <- coordinates(c(2, length(cor.y)))
  elpos[2,1] <- abs((elpos[1,1] + elpos[1,2]) / 2)

  ft1 <- matrix(ncol = 2, byrow = TRUE, data = c(1, 2))
  ft2 <- matrix(ncol = 2, byrow = FALSE, data = c(seq((2 + length(cor.y)))[3:(length(cor.y) + 2)], rep(2, length(cor.y))))
  fromto_CU <- t(combn(seq((2 + length(cor.y)))[3:(length(cor.y) + 2)], 2))
  fromto_ST <- rbind(ft1, ft2)

  nr <- nrow(fromto_ST)
  arrpos <- matrix(ncol = 2, nrow = nr)
  for (i in 1:nr)
    arrpos[i, ] <- straightarrow(to = elpos[fromto_ST[i, 2], ], from = elpos[fromto_ST[i, 1], ], lwd = 1, arr.pos = 0.1, arr.length = 0.1)

  text(arrpos[1, 1], arrpos[1, 2] + 0.05, paste("r", "x", nrow(cor.x) + 1, " = ", round(Path$Residual, 2), sep = ""), cex = 1, adj = c(1, 0))

  nr <- nrow(arrpos)
  for (i in 2:nr) {
    text(arrpos[i, 1], arrpos[i, 2] + 0.05, paste("P", "X", i - 1, " = ", round(diag(Path$Coeff)[i - 1], 2), sep = ""), cex = 1, adj = c(0, 1), srt = 45)
  }

  nr <- nrow(fromto_CU)
  arrpos <- matrix(ncol = 2, nrow = nr)
  for (i in 1:nr)
    arrpos[i, ] <- curvedarrow(to = elpos[fromto_CU[i, 2], ], from = elpos[fromto_CU[i, 1], ], lwd = 1, arr.pos = 0.8, arr.length = 0.1, curve = 1)

  nr <- nrow(fromto_CU)
  arrpos <- matrix(ncol = 2, nrow = nr)
  for (i in 1:nr)
    arrpos[i, ] <- curvedarrow(to = elpos[fromto_CU[i, 1], ], from = elpos[fromto_CU[i, 2], ], lwd = 1, arr.pos = 0.8, arr.length = 0.1, curve = -1)

  rcomb <- as.data.frame(t(combn(seq(nrow(cor.x)), 2)))
  rcomb <- paste(rcomb$V1, rcomb$V2, sep = "")
  path1 <- as.data.frame.array(Path[["Coeff"]], row.names = NULL, header = TRUE)
  write.csv(path1, file = "pathanlysis.csv")

  elements_after_diagonal <- vector()
  for (i in 1:nrow(path1)) {
    if (i < nrow(path1)) {
      elements_after_diagonal <- c(elements_after_diagonal, unname(path1[i, (i + 1):ncol(path1)]))
    }
  }

  path2 <- as.matrix(elements_after_diagonal)
  path2 <- as.numeric(path2)

  if (any(is.na(path2))) {
    warning("NA introduced during conversion, which indicates non-numeric values were present.")
  }

  path2 <- na.omit(path2)
  for (i in 1:length(path2)) {
    if (!is.na(path2[i])) {
      arrpos[i, ] <- curvedarrow(to = elpos[fromto_CU[i, 2], ], from = elpos[fromto_CU[i, 1], ], lwd = 1, arr.pos = 0.5, lcol = "transparent", arr.length = 0.1, curve = 1)
      text(arrpos[i, 1], arrpos[i, 2], paste("P", "X", i, " = ", round(path2[i], 2), sep = ""), cex = 0.8, adj = c(0, 1))
    } else {
      warning(paste("Skipping index", i, "due to NA value"))
    }
  }

  textrect(elpos[1, ], 0.04, 0.03, lab = "Residual", box.col = "tan1", shadow.col = "grey", shadow.size = 0.0002, cex = 1)
  textrect(elpos[2, ], 0.02, 0.03, lab = "GFY", box.col = "light blue", shadow.col = "grey", shadow.size = 0.0000002, cex = 1)
  nr <- nrow(elpos)
  for (i in 3:nr) {
    textrect(elpos[i, ], 0.02, 0.03, lab = colnames(x)[i - 2], box.col = "light green", shadow.col = "grey", shadow.size = 0.0000002, cex = 1)
  }
}
